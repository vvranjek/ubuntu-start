"""
compatibility with other Epics CA implementations
"""
from .epicsPV import epicsPV

